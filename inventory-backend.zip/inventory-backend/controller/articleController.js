
import pool from '../db.js';
import Joi from "joi";
import { DateTime } from "luxon";
import bwipjs from "bwip-js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { do_ma_query } from '../db.js';
// import { logActivity } from '../services/activityService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const outputDir = path.join(__dirname, "../barcodes");
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

// export const getArticle = async(req,res) =>{

// }


export const getArticle = async (req, res) => {
  try {
    const query = "SELECT id, title as name FROM article_profile ORDER BY title ASC";
    const article_profiles = await do_ma_query(query);

    res.status(200).json({
      success: true,
      data: article_profiles,
      timestamp: DateTime.local().toFormat("yyyy-MM-dd HH:mm:ss"),
    });
  } catch (error) {
    console.error("Error fetching article profiles:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching article profiles",
      error: error.message,
      timestamp: DateTime.local().toFormat("yyyy-MM-dd HH:mm:ss"),
    });
  }
};

